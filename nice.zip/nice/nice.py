from dragonfly import FocusWindow,Mouse, Window,Pause
from time import  sleep



delay=60
for i in range(0,3):
	sleep(delay)
	current = Window.get_foreground().executable
	FocusWindow("chrome").execute()
	sleep(1)
	Mouse("<150, -150>" if i%2==0 else "<-150, 150>").execute()
	sleep(1)
	FocusWindow(current).execute()







