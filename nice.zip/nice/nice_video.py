import json
import re


from time import  sleep
from  random import randint

from dragonfly import FocusWindow,Mouse, Window,Pause,Clipboard,Key
from dragonfly.actions.action_mouse import get_cursor_position

with open("nice.json","r") as f:
	data = json.load(f) 

def sleep_time_from_string(s):
	s = s.strip()
	m = re.match(r"(\d+):(\d+)\/(\d+):(\d+)", s)
	print(m.group(3),m.group(4))
	return int(m.group(3))*60 + int(m.group(4))
# 00:00/00:07
import sys

assert sleep_time_from_string("00:57/04:32")==(4*60+32)
assert sleep_time_from_string(" 00:57/04:32 ")==(4*60+32)
assert sleep_time_from_string("00:57/00:32")==(0*60+32)

def calibrate():
	for k in sorted(data.keys()):
		print(k)
		Mouse(str(data[k])).execute()
		sleep(4)
		data[k] = list(get_cursor_position())
		Mouse("<50,-50>").execute()
		sleep(0.5)
		Mouse("<-50,50>").execute()
		sleep(0.5)

def move(s,a=""):
	Mouse(str(data[s]) + "," + a).execute()
	sleep(1)

def next_video():
	move("p","left")
	sleep(2)
	# print(str(data["vb"]).replace("[","(").replace("]",")") + ",left:down/100," + "<100,0>" + ",left:up")
	# Mouse("(318,168)" + ",left:down/100," + "<100,0>").execute()
	# Mouse(str(data["vb"]).replace("[","(").replace("]",")") + ",left:down," + "<100,0>" + ",left:up").execute()
	Mouse(str(data["vb"]) + ",left:down/100," + str(data["ve"])).execute()
	Key("c-c").execute()
	sleep(1)
	s = Clipboard(from_system = True).get_system_text()
	Mouse("left:up").execute()
	print(s)
	
	# return 
	t = sleep_time_from_string(s)+10
	sleep(t)
	move("vn","left")
	sleep(5)

c = len(sys.argv)==2
if c:
	calibrate()
else:
	while True:
		next_video()

with open("nice.json","w") as f:
	json.dump(data,f) 


# delay=60
# for i in range(0,3):
# 	sleep(delay)
# 	current = Window.get_foreground().executable
# 	FocusWindow("chrome").execute()
# 	sleep(1)
# 	Mouse("<150, -150>" if i%2==0 else "<-150, 150>").execute()
# 	sleep(1)
# 	FocusWindow(current).execute()







