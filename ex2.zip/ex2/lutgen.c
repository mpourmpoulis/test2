#include <stdio.h>
#include <stdint.h>

#define bit(ii) ((i & (1<<ii)) >> ii)
#define One(ii) (1<<ii)




void gen_lut(uint8_t (*f)(uint8_t), char *s)
{
	printf("\n%s: db ",s);
	for(uint32_t i=0;i<=255;i++){
		uint8_t a = f((uint8_t)i);
		printf(" %02xh",a);
		if(i != 255) putchar(',');
	}
	putchar('\n');
}

uint8_t ask4(uint8_t i)
{
	uint8_t a3 = bit(7) & bit(6);
	uint8_t a2 = bit(5) & bit(4);
	uint8_t a1 = bit(3) | bit(2);
	uint8_t a0 = (bit(1) | bit(0)) ^ a0;
	return (a3<<3) | (a2<<2)|(a1<<1)|a0; //just the circuit
}

uint8_t ask3i(uint8_t i)
{
	return - (i & (-i)); //trick like in BIT tree i & (-i) gets the rightmost one
}

uint8_t ask3ii(uint8_t i)
{
	return i==1?0x01:
			i==8?0x10:0x00;
}

uint8_t ask3iii_read(uint8_t i)
{
	uint8_t line = (i>>3) & 0x07;
	if(!(bit(0) | bit(1))) return 0xFF;
	if(!(bit(0) | bit(2))) return 0xFF;
	if(!(bit(1) | bit(2))) return 0xFF; // max one key pressed
	if(bit(0) & bit(1) & bit(2)) return 0xFF; //// min one key pressed
	if(line >= 3) return 5 * (line-3) + (!bit(0)?0:!bit(1)?1:2); //most hex values

	if(line == 0 && !bit(0)) return 0x86;
	if(line == 0 && !bit(1)) return 0x85;
	if(line == 0 && !bit(2)) return 0xf7;
	if(line == 1 && !bit(0)) return 0x84;
	if(line == 1 && !bit(1)) return 0x80;
	if(line == 1 && !bit(2)) return 0x82;
	if(line == 2 && !bit(0)) return 0x00;
	if(line == 2 && !bit(1)) return 0x83;
	if(line == 2 && !bit(2)) return 0x81;
	return 0xFF;
}

uint8_t ask3iii_line(uint8_t i)
{
	if(i<8) return 0xFF ^ One(i);
	else return 0xFF;
}
int main(void){	
	gen_lut(ask3i,"lut");	
	gen_lut(ask3ii,"lut");	
	gen_lut(ask3iii_read,"read_trans");	
	gen_lut(ask3iii_line,"write_line");	
	gen_lut(ask4,"lut");	
}